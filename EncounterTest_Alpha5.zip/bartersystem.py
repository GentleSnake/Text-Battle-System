import random
from random import choice
import battlesystem
import os
def cls():
    os.system('clear')


def shopvisit():
    hstock = ["Thunder Wand", "Fire Wand", "Ice Wand", "Poison Spell", "Paralysis Spell" ]
    cls()
    print("You found a shop. The vendor has some items for sale:")
    stock = [choice(hstock), choice(hstock)]
    
    while stock[0] == stock[1]:
        stock.remove(stock[1])
        stock.append(choice(hstock))
        
    print(stock)
    print()
    buy = int(input("Do you want to buy anything? Yes(1) or No(2) "))
    if buy == 1:
        whichitem = int(input("Which do you want? Place one(1) or Place two(2)?"))
        if whichitem == 1:
            if stock[0] == hstock[0]:
                twand = True
                cost = 100
            elif stock[0] == hstock[1]:
                fwand = True
                cost = 80
            elif stock[0] == hstock[2]:
                iwand = True
                cost = 90
            elif stock[0] == hstock[3]:
                paralysis_spell = True
                cost = 50
            elif stock[0] == hstock[4]:
                poison_spell = True
                cost = 60
                
                
                
        elif whichitem == 2:
            if stock[1] == hstock[0]:
                twand = True
                cost = 100
            elif stock[1] == hstock[1]:
                fwand = True
                cost = 80
            elif stock[1] == hstock[2]:
                iwand = True
                cost = 90
            elif stock[1] == hstock[3]:
                paralysis_spell = True
                cost = 50
            elif stock[1] == hstock[4]:
                poison_spell = True
                cost = 60